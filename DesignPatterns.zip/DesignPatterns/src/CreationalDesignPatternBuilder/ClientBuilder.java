package CreationalDesignPatternBuilder;
//mostly we can use when we want to create immutable object
public class ClientBuilder {

	public static void main(String[] args) {
		
	User user=new User.UserBuilder().setEmailId("v@gmail").setUserName("vishal123").setUserId("1234").build();
		
	System.out.println(user);
		
	User user2=new User.UserBuilder().setEmailId("v1@gmail").setUserId("1234").build();
	System.out.println(user2);
	}

}
