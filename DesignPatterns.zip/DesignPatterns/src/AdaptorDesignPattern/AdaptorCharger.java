package AdaptorDesignPattern;

public class AdaptorCharger implements AppleCharger {

	private AndroidCharger charger;

	public AdaptorCharger(AndroidCharger charger) {
		super();
		this.charger = charger;
	}

	@Override
	public void chargePhone() {
		charger.chargAndroidPhone();
		System.out.println("Your phone is charging with adaptor");
	}

}
