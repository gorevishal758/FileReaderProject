package AdaptorDesignPattern;

public interface AndroidCharger {

	void chargAndroidPhone();
}
