package AdaptorDesignPattern;

public class ChargerXyz implements AppleCharger {

	@Override
	public void chargePhone() {
		
		System.out.println("Your phone charging.");
		
	}

}
