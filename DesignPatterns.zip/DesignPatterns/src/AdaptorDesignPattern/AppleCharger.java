package AdaptorDesignPattern;

public interface AppleCharger {

	void chargePhone() ;
}
