package AdaptorDesignPattern;

public class Main {

	public static void main(String[] args) {
		
		AppleCharger charger=new AdaptorCharger(new DkCharger());
		
		Iphone13 iphone13=new Iphone13(charger);
		iphone13.chargeIphone();
	}

}
