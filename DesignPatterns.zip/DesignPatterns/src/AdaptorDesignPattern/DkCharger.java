package AdaptorDesignPattern;

public class DkCharger implements AndroidCharger {

	@Override
	public void chargAndroidPhone() {

		System.out.println("Your android phone is charging");

	}

}
