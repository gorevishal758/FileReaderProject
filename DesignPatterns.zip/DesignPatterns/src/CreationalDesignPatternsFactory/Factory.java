package CreationalDesignPatternsFactory;

interface Employee{
	
	int getSalary();
	
}

class AndroidDev implements Employee{

	@Override
	public int getSalary() {
		
		int sal=50;
		
		System.out.println("Android Developer "+sal);
		return sal;
	}
	
	
}

class WebDev implements Employee{

	@Override
	public int getSalary() {

		int sal=80;
		
		System.out.println("Web Developer "+sal);
		return sal;
	}
	
	
}
public class Factory extends EmployeeFactory {

	public static void main(String[] args) {
		
		EmployeeFactory employee=new EmployeeFactory();
		
		Employee emp1=employee.getEmployee("JAVA DEVELOPER");
		System.out.println(emp1.getSalary());

	}

}
