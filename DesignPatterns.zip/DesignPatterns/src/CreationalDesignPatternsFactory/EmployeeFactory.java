package CreationalDesignPatternsFactory;

public class EmployeeFactory {

	public Employee getEmployee(String empType) {

		if (empType.trim().equalsIgnoreCase("ANDROID DEVELOPER")) {

			return new AndroidDev();
		} else if (empType.trim().equalsIgnoreCase("WEB DEVELOPER")) {

			return new WebDev();
		} else {
			return null;
		}
	}

}
