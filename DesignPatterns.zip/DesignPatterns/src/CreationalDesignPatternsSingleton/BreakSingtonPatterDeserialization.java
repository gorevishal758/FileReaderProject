package CreationalDesignPatternsSingleton;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class SingleDserilize implements Serializable{
	
	private static SingleDserilize de=new SingleDserilize();
	
	
	private SingleDserilize() {
		
		
	}
	public static SingleDserilize getInstance() {
		
		return de;
	}
	
	public Object readResolve() {  //when we method we got same hashcode in serialization and deserilization
		
		return de;
		
	}
	
}
public class BreakSingtonPatterDeserialization {

	public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {

		SingleDserilize sd1=SingleDserilize.getInstance();
		System.out.println(sd1.hashCode());
		
		ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream("abc.ob"));
		
		oos.writeObject(sd1);
		
		
		ObjectInputStream ois=new ObjectInputStream(new FileInputStream("abc.ob"));
		
		SingleDserilize sd2=(SingleDserilize) ois.readObject();
		System.out.println(sd2.hashCode());
	}

}
