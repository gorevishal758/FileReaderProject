package CreationalDesignPatternsSingleton;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

//There are two ways to create singleTon design pattern

// 1. Lazy 2.Eager

class Lazy {
	private static Lazy lazy;

	private Lazy() {
		System.out.println("Lazy calling...");
	}

	// If we want to use this way for Thread then we have to use synchronized
	// keyword else multiple thread create multiple object
	static Lazy getLazy() {

		if (lazy == null) {

			synchronized (Lazy.class) {
				if (lazy == null) {
					lazy = new Lazy();
				}
			}
		}
		return lazy;
	}
}

public class SingleTonLazy {

	public static void main(String[] args) throws NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		Lazy lazy1 = Lazy.getLazy();
		Lazy lazy2 = Lazy.getLazy();
		System.out.println(lazy1.hashCode());
		System.out.println(lazy2.hashCode());
		
		//We can break singleton pattern using reflection API
		
		Constructor<Lazy> con=Lazy.class.getDeclaredConstructor();
		con.setAccessible(true);
		Lazy lazy3=con.newInstance();
		System.out.println(lazy3.hashCode());

	}

}
