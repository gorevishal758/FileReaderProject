package CreationalDesignPatternsSingleton;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

class Eager{
	
	private static Eager eager=new Eager();
	
	private Eager() {
		
	}
	
	public static Eager getEager() {
		
		return eager;
	}
}
public class SingleTonEager {

	public static void main(String[] args) throws NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		
		Eager eg1=Eager.getEager();
		Eager eg2=Eager.getEager();
		System.out.println(eg1.hashCode());
		System.out.println(eg2.hashCode());
		
		Constructor<Eager> con=Eager.class.getDeclaredConstructor();
		con.setAccessible(true);
		Eager eg3=con.newInstance();
		System.out.println(eg3.hashCode());
		
	}

}
