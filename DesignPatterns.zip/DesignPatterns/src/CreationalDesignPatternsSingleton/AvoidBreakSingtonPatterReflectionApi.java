package CreationalDesignPatternsSingleton;

import java.lang.reflect.Constructor;

import javax.management.RuntimeErrorException;

//method1 to avoid to break singleton patter
class Sing{
	
	private static  Sing sing;
	 
	//one way : Using exception
	private Sing() {
		if(sing	!=null) {
			
			throw new RuntimeException("Your trying to break singleton patter");
		}
		
	}
	
	
	
	public static Sing getInstance() {
		
		if(sing==null) {
			
			
			synchronized (Sing.class) {
				
				if(sing==null) {
					
					sing=new Sing();
				}
			}
		}
		return sing;
	}
}


//way 2 using enum keyword

enum SingWay{
	INSTANCE;
	
}
public class AvoidBreakSingtonPatterReflectionApi {

	public static void main(String[] args) throws Exception{

		/*
		 * Sing sg1=Sing.getInstance(); System.out.println(sg1.hashCode());
		 * 
		 * // breaking singleton patter
		 * 
		 * Constructor<Sing> con=Sing.class.getDeclaredConstructor();
		 * 
		 * con.setAccessible(true);
		 * 
		 * Sing sg2=con.newInstance();
		 * 
		 * System.out.println(sg2.hashCode());
		 */
		
		//
		SingWay singWay=SingWay.INSTANCE;
		
		System.out.println(singWay.hashCode());
		
		Constructor<SingWay> con1=SingWay.class.getDeclaredConstructor();
		
		con1.setAccessible(true);
		
		SingWay sg4=con1.newInstance();
		
		System.out.println(sg4.hashCode());
		
		
	
	}

}
