package CreationalDesignPatternsSingleton;

class Lsingle  implements Cloneable{
	
	private static Lsingle lsing;
	
	private Lsingle() {
		
	}
	
	public static Lsingle getInstance() {
		
		if(lsing==null) {
			
			
			lsing =new Lsingle();
		}
		return lsing;
	}
	
	@Override
	public Object clone() throws CloneNotSupportedException {
		
		return super.clone();
	}
	
	
}
public class BreakSingtonPatterCloning {

	public static void main(String[] args) throws CloneNotSupportedException {

		Lsingle l1=Lsingle.getInstance();
		System.out.println(l1.hashCode());
		
		Lsingle l2=(Lsingle)l1.clone();
		
		System.out.println(l2.hashCode());

	}

}
