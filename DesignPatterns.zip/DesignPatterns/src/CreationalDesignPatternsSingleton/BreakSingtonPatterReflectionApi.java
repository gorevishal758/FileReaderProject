package CreationalDesignPatternsSingleton;

import java.lang.reflect.Constructor;

class SingleLazy{
	
	private static SingleLazy singleLazy;
	
	private SingleLazy() {
		
	}
	
	public static SingleLazy getInstance() {
		
		
		if(singleLazy==null) {
			// If we want to use this way for Thread then we have to use synchronized
			// keyword else multiple thread create multiple object
			synchronized (SingleLazy.class) {
				
				if(singleLazy==null) {
					
					singleLazy=new SingleLazy();
				}
			}
			
			
		}
		return singleLazy;
	}
}

class SingleEager{
	
	//using Eager Method
	private static SingleEager single=new SingleEager();
	
	private SingleEager (){
		
	}
	
	public static SingleEager getInstance() {
		
		return single;
	}
}

public class BreakSingtonPatterReflectionApi  {

	public static void main(String[] args)throws Exception {

		SingleEager sg1=SingleEager.getInstance();
		
		System.out.println(sg1.hashCode());
		
		// To break Single pattern using Reflection api method :1
		
	Constructor<SingleEager> con=SingleEager.class.getDeclaredConstructor();
	con.setAccessible(true);
	SingleEager sg3=con.newInstance();
	System.out.println(sg3.hashCode());
	}

}
