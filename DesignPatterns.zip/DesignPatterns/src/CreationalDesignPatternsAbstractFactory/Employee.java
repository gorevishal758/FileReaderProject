package CreationalDesignPatternsAbstractFactory;

public interface Employee {

	int salary();
	String name();
}
