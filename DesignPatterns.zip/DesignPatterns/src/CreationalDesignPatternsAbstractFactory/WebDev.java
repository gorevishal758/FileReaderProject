package CreationalDesignPatternsAbstractFactory;

public class WebDev implements Employee{

	@Override
	public int salary() {
		// TODO Auto-generated method stub
		return 40000;
	}

	@Override
	public String name() {
		System.out.println("I am Web developer");
		
		return "WEB";
	}

}
