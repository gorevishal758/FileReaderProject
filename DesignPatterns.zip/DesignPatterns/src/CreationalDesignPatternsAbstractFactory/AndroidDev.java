package CreationalDesignPatternsAbstractFactory;

public class AndroidDev implements Employee {

	@Override
	public int salary() {
		// TODO Auto-generated method stub
		return 5000;
	}

	@Override
	public String name() {
		
		System.out.println("I am android Developer");
		return "Android";
	}

}
