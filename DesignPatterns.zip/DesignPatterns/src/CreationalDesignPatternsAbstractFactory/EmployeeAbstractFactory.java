package CreationalDesignPatternsAbstractFactory;

abstract public class EmployeeAbstractFactory {

	public abstract Employee createEmployee();
}
