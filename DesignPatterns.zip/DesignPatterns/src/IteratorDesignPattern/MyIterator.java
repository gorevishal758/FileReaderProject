package IteratorDesignPattern;

public interface MyIterator {

	boolean hasNext();
	Object next();
}
