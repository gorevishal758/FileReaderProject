package IteratorDesignPattern;

public class Main {

	public static void main(String[] args) {
		
		UserManagment usermg=new UserManagment();
		
		usermg.addUser(new User("vishal","122"));
		usermg.addUser(new User("Ram","121"));
		usermg.addUser(new User("shaym","123"));
		usermg.addUser(new User("akshay","124"));
		
		MyIterator myitr=usermg.getIterator();
		
		while(myitr.hasNext()) {
			
			User user=(User) myitr.next();
			
			System.out.println(user.getName()+" : "+user.getUserId());
		}
	}

}
