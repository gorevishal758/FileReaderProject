package ObserverDesignPattern;

public interface Observer {

	void notified(String title);
}
