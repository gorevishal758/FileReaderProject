package ObserverDesignPattern;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class MainClass {

	public static void main(String[] args) throws NumberFormatException, IOException {

		YouTubeChannel you = new YouTubeChannel();
		
		Subscriber aman=new Subscriber("Aman");
		Subscriber raman=new Subscriber("Raman");
		
		you.subscribe(aman);
		you.subscribe(raman);
		
		you.newVideoUploaded("Learn Design Pattern");
		you.newVideoUploaded("New angular course");
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		while(true) {
			
			System.out.println("Press 1 to upload video ");
			System.out.println("Press 2 to create new subscriber ");
			System.out.println("Press 3 to exit ");
			
			int c=Integer.parseInt(br.readLine());
			
			if(c==1 ) {
				System.out.println("Enter video title");
				String videoTitle=br.readLine();
				you.newVideoUploaded(videoTitle);
				
				
				
			}else if(c==2) {
				
				System.out.println("Enter the name of subscrier ");
				String subName=br.readLine();
				Subscriber subscriber3	=new Subscriber(subName);
				you.subscribe(subscriber3);
			}
			else if(c==3) {
				
				System.out.println("Thanks for using app ");
				break;
			}else {
				
				System.out.println("Wrong input ");
			}
		}

	}

}
