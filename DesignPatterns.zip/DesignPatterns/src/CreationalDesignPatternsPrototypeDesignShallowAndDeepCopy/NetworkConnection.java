package CreationalDesignPatternsPrototypeDesignShallowAndDeepCopy;

import java.util.ArrayList;
import java.util.List;

public class NetworkConnection implements Cloneable{
	private String ip;
	private String impData;
	
	private List<String> domain=new ArrayList<>();
	
	
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getImpData() {
		return impData;
	}
	public void setImpData(String impData) {
		this.impData = impData;
	}
	
	
	public List<String> getDomain() {
		return domain;
	}
	public void setDomain(List<String> domain) {
		this.domain = domain;
	}
	
	public void loadImpData() {
		
		this.impData="Very very imp data";
		
		domain.add("www.ggogle.com");
		domain.add("www.yash.com");
		domain.add("www.yahoo.com");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public String toString() {
		return this.ip+ "  :"+this.impData+"  :"+this.domain;
	}
	@Override
	protected Object clone() throws CloneNotSupportedException {
		//Logic for deep clonning
		NetworkConnection network=new NetworkConnection();
		
		network.setIp(this.getIp());
		network.setImpData(this.getImpData());
		
		for(String s:this.getDomain()) {
			network.getDomain().add(s);
		}
		
		return network;
	}
	
	

}
