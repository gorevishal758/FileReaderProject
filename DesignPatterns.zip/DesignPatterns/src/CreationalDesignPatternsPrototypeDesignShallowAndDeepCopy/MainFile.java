package CreationalDesignPatternsPrototypeDesignShallowAndDeepCopy;

public class MainFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Creating object using prototype design pattern.");
	
	NetworkConnection net=new NetworkConnection();
	
	net.setIp("192.168.4.4");
	net.loadImpData();
	
	
	
	
	
	//we want new object of network connection
	NetworkConnection net2;
	try {
		net2=(NetworkConnection)net.clone();
		
		System.out.println(net);
		
		net.getDomain().remove(0);
		System.out.println(net);
		System.out.println(net2);
	} catch (CloneNotSupportedException e) {
		
		e.printStackTrace();
	}
		
	}

}
