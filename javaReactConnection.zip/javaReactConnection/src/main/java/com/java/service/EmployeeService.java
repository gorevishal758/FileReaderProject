package com.java.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.java.dto.EmployeeDto;


public interface EmployeeService {

	EmployeeDto createEmployee(EmployeeDto employeeDto);
	
	EmployeeDto getEmployeeById(int id);
	
	List<EmployeeDto> getAllEmployee();
	
	EmployeeDto updateEmployee(int id,EmployeeDto updatedEmployeeDto);
	
	void deleteEmployeeById(int id);
}
