package com.java.impl;

import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.java.dto.EmployeeDto;
import com.java.entity.Employee;
import com.java.exception.ResourceNotFoundException;
import com.java.mapper.EmployeeMapper;
import com.java.repo.EmployeeRepository;
import com.java.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;
//post mapping
	@Override
	public EmployeeDto createEmployee(EmployeeDto employeeDto) {

		Employee employee = EmployeeMapper.mapToEmployee(employeeDto);

		Employee saveEmployee = employeeRepository.save(employee);

		return EmployeeMapper.mapToEmployeeDto(saveEmployee);
	}
	
	
//get mapping find by id
	@Override
	public EmployeeDto getEmployeeById(int id) {
		
		Employee employee=employeeRepository.findById(id).
		orElseThrow(()->new ResourceNotFoundException("Employee is not present "+id));
		return EmployeeMapper.mapToEmployeeDto(employee);
	}
//find all

	@Override
	public List<EmployeeDto> getAllEmployee() {
		List<Employee> getEmployees=employeeRepository.findAll();
		
		
		return getEmployees.stream().map((emp)->EmployeeMapper.mapToEmployeeDto(emp))
				.collect(Collectors.toList());
	}

//update employee
	@Override
	public EmployeeDto updateEmployee(int id, EmployeeDto updatedEmployeeDto) {


		Employee employee=employeeRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("Employee not exist"+id));
		
		employee.setFirstName(updatedEmployeeDto.getFirstName());
		employee.setLastName(updatedEmployeeDto.getLastName());
		employee.setEmail(updatedEmployeeDto.getEmail());
		
		Employee updatedEmployee=employeeRepository.save(employee);
		
		
		return EmployeeMapper.mapToEmployeeDto(updatedEmployee);
	}


	@Override
	public void deleteEmployeeById(int id) {
		
		employeeRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("Id not present :"+id));
	
		employeeRepository.deleteById(id);
	
	
	}

}
