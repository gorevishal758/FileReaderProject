package interviewAsked;
import java.util.*;
import java.io.*;
public class Questions2 {
	
	/*
	 * Take the input line from argument, which will contain only alphabetic
	 * characters and spaces, and return the first non-repeating character. For
	 * example: if str is "agettkgaeee" then your program should return k. The
	 * string will always contain at least one character and there will always be at
	 * least one non-repeating character.
	 * 
	 * Examples
	 * 
	 * Input: "abcdef" Output: a
	 * 
	 * Input: "hello world hi hey" Output: w
	 */

	
	public static void main (String[] args) {
	    // Arguments will be read by STDIN
	    Scanner s = new Scanner(System.in); // do not change this
	    String inputLine = s.nextLine(); // do not change this

	    // you code will be inside this main method
	             String[] c= inputLine.split("");
	             int count;
	         for(int i=0;i<c.length;i++){
	            count=1;

	            for(int j=i+1;j<c.length;j++){
	              if(c[i].equals(c[j])){

	                count++;
	                c[j]="0";
	              }
	            }
	            if(count==1 ){
	              System.out.print(c[i]);
	              break;
	            }
	         }     

	    // to view the output, just print the string

	    // below is a sample program output
	    
	  }
	}



