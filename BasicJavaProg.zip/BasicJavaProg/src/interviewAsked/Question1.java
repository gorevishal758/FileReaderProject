package interviewAsked;

import java.util.*;
import java.io.*;

public class Question1 {

	/*
	 * Take the input line from argument and divide into array of strings based on
	 * :: delimiter, which will contain 2 elements: the first element will be a
	 * sequence of characters, and the second element will be a long string of
	 * comma-separated words, in alphabetical order, that represents a dictionary of
	 * some arbitrary length. For example: str can
	 * be:"hellocat::apple,bat,cat,goodbye,hello,yellow,why". Your goal is to
	 * determine if the first element in the input can be split into two words,
	 * where both words exist in the dictionary that is provided in the second
	 * input. In this example, the first element can be split into two words: hello
	 * and cat because both of those words are in the dictionary.
	 * 
	 * Your program should return the two words that exist in the dictionary
	 * separated by a comma. So for the example above, your program should return
	 * hello,cat. There will only be one correct way to split the first element of
	 * characters into two words. If there is no way to split string into two words
	 * that exist in the dictionary, return the string not possible. The first
	 * element itself will never exist in the dictionary as a real word. Examples
	 * Input: "baseball::a,all,b,ball,bas,base,cat,code,d,e,quit,z" Output:
	 * base,ball
	 * 
	 * Input: "abcgefd::a,ab,abc,abcg,b,c,dog,e,efd,zzzz" Output: abcg,efd
	 */

	public static void main(String[] args) {
		// Arguments will be read by STDIN
		Scanner s = new Scanner(System.in); // do not change this
		String inputLine = s.nextLine(); // do not change this

		String[] splitString = inputLine.split("::");

		if (splitString.length != 2) {
			System.out.print("split not possible");
		}
		String word = splitString[0];
		String dictionaryWord = splitString[1];

		Set<String> set = new HashSet<>(Arrays.asList(dictionaryWord.split(",")));

		for (int i = 0; i < word.length(); i++) {

			String word1 = word.substring(0, i);
			String word2 = word.substring(i);

			if (set.contains(word1) && set.contains(word2)) {

				System.out.print(word1 + "," + word2);
				break;

			}
		}

	}
}
