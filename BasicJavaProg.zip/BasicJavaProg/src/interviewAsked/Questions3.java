package interviewAsked;
import java.util.*;
import java.io.*;
public class Questions3 {
	/*
	 * Take the input line from argument and return the string true if every single
	 * letter of the English alphabet exists in the string, otherwise return the
	 * string false. For example: if str is "zacxyjbbkfgtbhdaielqrm45pnsowtuv" then
	 * your program should return the string true because every character in the
	 * alphabet exists in this string even though some characters appear more than
	 * once.
	 */
	 public static void main (String[] args) {
		    // Arguments will be read by STDIN
		    Scanner s = new Scanner(System.in); // do not change this
		    String inputLine = s.nextLine(); // do not change this
		  
		 Set<Character> set=new HashSet<>();

		 for(char chr:inputLine.toUpperCase().toCharArray()){
		  if(Character.isLetter(chr)){
		    set.add(chr);
		  }
		 }
		  if(set.size()==26){

		     System.out.print("true");
		  }
		    else{
		System.out.print("false");
		    }
		    
		  }
		}

