package MultiThreading;


class Counter {

	private int count = 0;

	public synchronized void increment() {
		count++;
	}

	public int getCount() {
		return count;
	}
}

public class ObjectLevelSync {

	public static void main(String[] args) {
		 Counter counter1 = new Counter();
	        Counter counter2 = new Counter();
	 
	        // Threads operating on counter1
	        new Thread(() -> {
	            for (int i = 0; i < 900; i++) {
	                counter1.increment();
	            }
	            System.out.println("Counter 1: " + counter1.getCount());
	        }).start();
	 
	        // Threads operating on counter2
	        new Thread(() -> {
	            for (int i = 0; i < 1000; i++) {
	                counter2.increment();
	            }
	            System.out.println("Counter 2: " + counter2.getCount());
	        }).start();
	    }
	}


