package MultiThreading;


class Counterx {
    private static int count = 0;
 
    // Class-level synchronization
    public static synchronized void increment() {
        count++;
    }
 
    public static int getCount() {
        return count;
    }
}
 
public class ClassLevelSync {
    public static void main(String[] args) {
        // Threads operating on the class-level synchronized method
        new Thread(() -> {
            for (int i = 0; i < 2000; i++) {
                Counterx.increment();
            }
            System.out.println("Counter: " + Counterx.getCount());
        }).start();
 
        new Thread(() -> {
            for (int i = 0; i < 1000; i++) {
                Counterx.increment();
            }
            System.out.println("Counter: " + Counterx.getCount());
        }).start();
    }
}

