package Basic;

import java.util.Arrays;

public class MaximumProductDifferenceBetweenTwoPairs {

	public static void main(String[] args) {
		
		int[] nums = {5,6,2,7,4};
		Arrays.sort(nums);
		//System.out.println(Arrays.toString(nums));
		int res=0;
		for(int i=0 ;i<nums.length;i++) {
			
			res=nums[nums.length-1]*nums[nums.length-2]-nums[0]*nums[1];
			
		}
		System.out.println(res);
	}

}
