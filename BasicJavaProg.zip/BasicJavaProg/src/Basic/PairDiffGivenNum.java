package Basic;

import java.util.HashSet;
import java.util.Set;

public class PairDiffGivenNum {

	public static void main(String[] args) {
	
		int[] arr={1,2,5,10,6};
		int diff= -5;
		
		
		Set<Integer> set=new HashSet<>();
		
		for(int num:arr) {
			
			if(set.contains(num+diff)) {  
				
				System.out.println("pair found  ( "+num+" ,"+(num+diff)+")");
			}
			
			if(set.contains(num-diff)) {
				System.out.println("pair found  ( "+num+" ,"+(num-diff));
			}
			
			set.add(num);
			
			}
		}
	
}
