package Basic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
class Easy{
	
	public void test() {
	int[]	arr = {1,2,2,2,1,1,3};
		
		List<Integer> list=new ArrayList<>();
		
		
		for(int num:arr) {
			
			list.add(num);
		}
		
	Map<Integer,Long> map=	list.stream().collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
		
		
		for(Map.Entry<Integer,Long> res:map.entrySet()) {
			
			if(res.getValue() <=1) {
				
				System.out.println();
			}
		}
	}
}
public class UniqueNumberofOccurrences {

	public static void main(String[] args) {
		int[]	arr = {1,2,2,2,1,1,3};
		
	    Map<Integer, Integer> frequencyMap = new HashMap<>();
		
		
	    for (int num : arr) {
            frequencyMap.put(num, frequencyMap.getOrDefault(num, 0) + 1);
           
        }
	    
	    Set<Integer> occurrences = new HashSet<>(frequencyMap.values());
	    
	    System.out.println(occurrences);
        if(occurrences.size() == frequencyMap.size()) {
        	
        	System.out.println(true);
        }
        else {
        	System.out.println(false);
        }
		
	}

}
