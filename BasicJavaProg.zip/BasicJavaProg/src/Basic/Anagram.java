package Basic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class AnagramNum {

	public void anagram() {

		int[] numbers = { 123, 321, 456, 789, 132, 231 };

		for (int i = 0; i < numbers.length; i++) {

			for (int j = i + 1; j < numbers.length; j++) {

				char[] num1 = Integer.toString(numbers[i]).toCharArray();

				char[] num2 = Integer.toString(numbers[j]).toCharArray();

				Arrays.sort(num1);
				Arrays.sort(num2);

				if (Arrays.equals(num1, num2)) {

					System.out.println(numbers[i] + " and " + numbers[j] + " are anagrams.");
				}

			}
		}
	}
}

class AnagramString {

	public void anagram() {

		String[] words = { "listen", "silent", "apple", "banana", "earth", "heart" };

		for (int i = 0; i < words.length; i++) {

			for (int j = i + 1; j < words.length; j++) {
				
				String str1=words[i];
				String str2=words[j];
				
				char[] c1=str1.toCharArray();
				char[] c2=	str2.toCharArray();
				
				
				Arrays.sort(c1);
				Arrays.sort(c2);
				
				if(Arrays.equals(c1,c2)) {
					System.out.println(words[i] + " and " + words[j] + " are anagrams.");
				}
				
			}
		}
	}

}


class AnagramCollectionWord{
	
	public void anagram() {
		
		String[] words = { "listen", "silent", "apple", "banana", "earth", "heart" };
		List<String> list=new ArrayList<>();
		for(String word:words) {
			
			list.add(word);
		}
		
		
	}
}
public class Anagram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnagramNum a = new AnagramNum();
		 a.anagram();

		AnagramString a2 = new AnagramString();
		a2.anagram();
	
		AnagramCollectionWord ac=new AnagramCollectionWord();
		ac.anagram();
	}

}
