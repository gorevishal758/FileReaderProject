package Basic;

import java.util.Arrays;

public class SumOfAllEvenNum {

	public int sum(int num[]) {
		
		
		
		
		int a=Arrays.stream(num).filter(i->i%2==0).sum();
		
		
		return a;
	}
	public static void main(String[] args) {
		
		int num[]= {1,2,3,4,5,6,7,8,9,10};
		  SumOfAllEvenNum obj = new SumOfAllEvenNum();
	        int result = obj.sum(num);
	        System.out.println("Sum of all even numbers: " + result);
	}

}
