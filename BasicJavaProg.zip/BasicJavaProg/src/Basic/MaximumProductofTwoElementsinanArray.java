package Basic;

import java.util.Arrays;

public class MaximumProductofTwoElementsinanArray {

	public static void main(String[] args) {

int[] nums = {3,4,5,2,6};

Arrays.sort(nums);


int res = 0;
for(int i=0;i<nums.length;i++) {
	
	res=nums[nums.length-1-1]*nums[nums.length-2-1];
	
}System.out.println(res);

	}

}
