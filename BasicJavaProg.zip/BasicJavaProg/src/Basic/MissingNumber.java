package Basic;

import java.util.Arrays;

public class MissingNumber {

	public static void main(String[] args) {

		int[] arr = { -2, -3, -1, 1, 4, 5, 2, 6, 8 };
		int temp;
		int diff = 0;
		Arrays.sort(arr);
		for (int x = 0; x < arr.length - 1; x++) {

			diff = arr[x + 1] - arr[x];
			if (arr[x] > 0) {
				if (arr[x] >= 0 && diff > 1) {

					System.out.println(arr[x] + 1);

				}

			}

		}

	}

}
