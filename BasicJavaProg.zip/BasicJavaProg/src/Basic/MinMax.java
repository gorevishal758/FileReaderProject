package Basic;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

class charSwap{
	
	public void swap() {
		String[] words = {"cat","bt","hat","tree"}; 
			String chars = "atach";
			int totalLen=0;
			int [] charCount=new int[1000];
			
			for(char c:chars.toCharArray()) {
				
				charCount[c-'a']++ ;
				//System.out.println(c+" "+charCount[c-'a']);
			}
			
			for (String word : words) {
	            int[] tempCharCount = charCount.clone(); // Make a copy of the frequency array
	            boolean goodWord = true;
	            for (char c : word.toCharArray()) {
	                if (--tempCharCount[c - 'a'] < 0) {
	                	
	                	
	                    goodWord = false; // Character not available
	                    break;	
	                }
	            }
	            if (goodWord) {
	            	totalLen += word.length(); // Increment length if word is good
	            }
	        }
	        
	        System.out.println("Output for Example 1: " + totalLen); // Output: 6
	        
	}
}
class Solution {
	public void Add() {

		String[] word1 = { "a","b", "c","d" };
		String[] word2 = { "a", "bc" };

		String sum1 = "";
		String sum2="";
		int c;
		for (int i = 0; i < word1.length; i++) {

			sum1 = sum1 + word1[i];
		}
		for (int j = 0; j < word2.length; j++) {

			sum2 = sum2 + word2[j];
		}

		if (sum1.equals(sum2)) {
			System.out.println("Equal");
		} else {
			System.out.println("Not equal");
		}
	}
}

public class MinMax {

	public static void main(String[] args) {

		int arr[] = { 1, 3, 4, 5, 6, 9 };

		int i;
		int max = arr[0];

		for (i = 1; i < arr.length; i++) {

			if (max < arr[i]) {

				max = arr[i];
			}

		}
		System.out.println(max);

		List<Integer> list = Arrays.asList(1, 2, 4, 5, 7);

		Optional<Integer> x = list.stream().reduce((a, b) -> a > b ? a : b);
		System.out.println(x.get());

		List<Integer> list1 = Arrays.asList(1, 2, 4, 5, 7);
		int target = 3; // Condition: elements greater than this value

		Optional<Integer> maxElement = list1.stream().filter(j -> {
			return j > target;
		}).max((a, b) -> {
			return a.compareTo(b);
		});
		System.out.println(maxElement.get());

		Solution s = new Solution();
		s.Add();
		charSwap c=new charSwap();
		c.swap();
	}

}
