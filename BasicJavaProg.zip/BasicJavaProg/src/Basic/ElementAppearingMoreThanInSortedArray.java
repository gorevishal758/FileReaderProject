package Basic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

class UsingCollection {

	public int getResult() {

		int[] arr = { 1, 3, 2, 7, 10 };

		List<Integer> list = new ArrayList<>();

		for (int num : arr) {

			list.add(num);
		}

		Map<Integer, Long> map = list.stream()
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

		int per = (int) (list.size() * 0.25);

		for (Map.Entry<Integer, Long> entry : map.entrySet()) {

			if (entry.getValue() > per) {

				return entry.getKey();
			}
		}
		return -1;
	}
}

class WithoutUsingCollection {

	int[] arr = { 1, 2, 2, 6, 6, 6, 6, 7, 10 };

	int per = (int) (arr.length * 0.25);

	public void getValue() {

		int maxValue=Integer.MIN_VALUE;
		
		for(int num:arr) {
			
			maxValue=Integer.max(maxValue,num);
		}
		
		int[] count=new int[maxValue+1];
		
		for(int num :arr) {
			
			count[num]++;
		}
		
		for(int i=0 ;i<count.length ;i++) {
			
			if(count[i]>0  && count[i] >per) {
				
				System.out.println(i + "\t" + count[i]);
				
				
			}
		}
	}
}

public class ElementAppearingMoreThanInSortedArray {

	public static void main(String[] args) {
		UsingCollection c = new UsingCollection();
		int result = c.getResult();
		System.out.println("Element appearing more than 25% of the time: " + result);

		WithoutUsingCollection wc = new WithoutUsingCollection();
		wc.getValue();
	}

}
