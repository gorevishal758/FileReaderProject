package Basic;

public class PivotInteger {

	public static void main(String[] args) {
		
		int n=8;
		int rightSum = 0,leftSum=0;
		  int totalSum = (n * (n + 1)) / 2;
//1 + 2 + 3 + 4 + 5 + 6 = 6 + 7 + 8 = 21.  sum1=1 to x  sum2=x to n
		
		for(int i=1 ;i<=n ;i++) {
			
			 rightSum = totalSum - leftSum - i;  
			 if(leftSum==rightSum) {
				 
				 System.out.println("pivote no :"+i);
			 }
			leftSum=leftSum+i; 
			
		}System.out.println(totalSum);
		System.out.println(rightSum);
		System.out.println(leftSum);
	}

}
