package Basic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.OptionalInt;
import java.util.function.Function;
import java.util.stream.Collectors;

class StringPg {

}

public class PracticeOnly {

	public static void main(String[] args) {

		int[]  nums = {3,0,1};
	
		int n=nums.length;   //3
		int expectedSum=n*(n+1)/2; //6
		System.out.println(expectedSum);
		int actualLength=0;
		
		
		for(int num:nums) {
			actualLength+=num;  
			//System.out.println(actualLength);
			
		}
		System.out.println(expectedSum-actualLength);
		 
	}
}