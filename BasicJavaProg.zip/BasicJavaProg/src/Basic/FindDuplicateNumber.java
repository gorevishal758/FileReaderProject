package Basic;

import java.util.HashSet;
import java.util.Set;

class ForLoop{
	
	public void find(int[] nums) {
		
		
		
		for(int i=0;i<nums.length-1;i++) {
			
			for(int j=i+1;j<nums.length;j++) {
				
				if(nums[i]==nums[j] && i !=j) {
					
					System.out.println(nums[i]);
				}
				
			}
		}
	}
}

class Hashset{
	
	public void find(int[] nums) {
		
		Set<Integer> set=new HashSet<>();
		
		for(int i:nums) {
			
			if(set.add(i)==false) {
				
				System.out.println(i);
			}
		}
	}
}
public class FindDuplicateNumber {

	public static void main(String[] args) {

		int[] nums= {1,23,4,5,7,4,8,8};
		ForLoop f=new ForLoop();
		f.find(nums);
		
		Hashset h=new Hashset();
		h.find(nums);

	}

}
