package Basic;

public class SecondLargestElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 5, 7, 7, 7, 6 };
		int max = Integer.MIN_VALUE;
		int smax = Integer.MIN_VALUE;

		for (int i = 0; i < arr.length; i++) {

			if (arr[i] > max) {

				smax = max;
				max = arr[i];

			}
			if (arr[i] > smax && arr[i] != max) {

				smax = arr[i];
			}

		}

		if (smax == Integer.MIN_VALUE) {
			System.out.println("There is no second largest element.");
		} else {
			System.out.println("The second largest element is: " + smax);
		}
	}

}
