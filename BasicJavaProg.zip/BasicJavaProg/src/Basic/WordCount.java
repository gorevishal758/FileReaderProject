package Basic;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class WordCount {

	public static void main(String[] args) {


		List<String> list=Arrays.asList("apple","banana","apple","orange","apple");
		
		
		list.stream().collect(Collectors.groupingBy(Function.identity(),Collectors.counting()))
		.forEach((a,b)->System.out.println(a+"  : "+b));
		
		long i=list.stream().filter(word->word.equals("apple")).count();
		
		System.out.println(i);
	}

}
