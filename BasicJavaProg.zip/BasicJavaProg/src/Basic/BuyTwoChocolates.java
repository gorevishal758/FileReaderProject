package Basic;

import java.util.Arrays;

public class BuyTwoChocolates {

	public static void main(String[] args) {
		
	
				
			int [] prices= {1,2,2};
			int money=3;
			int res;
			
			Arrays.sort(prices);
			
			for(int i=0 ;i<prices.length ;i++) {
				
				
				if((prices[0]+prices[1])<=money) {
					
					res=money-(prices[0]+prices[1]);
					
					System.out.println(res);
				} 
				else {
					
					System.out.println(money);
				}
			}System.out.println(money);

	}

}
