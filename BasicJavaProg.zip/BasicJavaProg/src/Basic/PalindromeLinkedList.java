package Basic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.Stack;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;

public class PalindromeLinkedList {

	public static void main(String[] args) {
		
		List<Integer> l=new ArrayList<>();
		
		l.add(3);
		l.add(4);
		l.add(3);
		l.add(2);
		l.add(1);
		
		System.out.println(l);
		
		ListIterator<Integer> itr=l.listIterator(l.size()	);
		
		System.out.println(itr.getClass().getName());
		while(itr.hasPrevious()) {
			
			System.out.println(itr.previous());
		}

		
		System.out.println("****************************************");
		
		PriorityQueue<Integer> pr=new PriorityQueue<>();

for(int i=0 ;i<=10;i++) {
	
	pr.offer(i);
}
		System.out.println(pr);
		
	System.out.println("*****************MultiMap***********************");

	
		
	

		LinkedList<Integer> link=new LinkedList<>();
		
		link.add(1);
		link.add(2);
		link.add(1);
		
		Stack<Integer> stack = new Stack<>();
		
		 for (int i = 0; i < link.size(); i++) {
	            stack.push(link.get(i));
	        }
	
	
		 for (int i = 0; i < link.size(); i++) {
	            if (!link.get(i).equals(stack.pop())) {

System.out.println("not");
	            }
	            else {
	            	System.out.println("Pal");
	            }
	        }
}
}