package Basic;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class FirstUniqueCharacterInString {

	public static void main(String[] args) {

		String s = "leetcode";

		Map<Character, Long> map = s.chars().mapToObj(c -> (char) c)
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

		for (int i = 0; i < s.length(); i++) {

			if (map.get(s.charAt(i)) == 1) {

				System.out.println(i);

			}
		}

	}

}
