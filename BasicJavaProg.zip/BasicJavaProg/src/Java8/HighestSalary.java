package Java8;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class HighestSalary {

	public static void main(String[] args) {

		List<Integer> high=Arrays.asList(2000,5000,8000,3000);
		
		Optional<Integer> i=high.stream().max((a,b)->a.compareTo(b));
		
		System.out.println(i.get());

	}

}
