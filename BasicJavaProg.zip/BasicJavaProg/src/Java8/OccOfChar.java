package Java8;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class OccOfChar {

	public static void main(String[] args) {

		String str = "Vishal";
		
		Arrays.stream(str.split("")).collect(Collectors
				.groupingBy(Function.identity(),Collectors.counting())).
		forEach((a,b)->System.out.println(a+" :"+b));;
		
		
		Map	map=Arrays.stream(str.split("")).collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
		
		//map.forEach((a,b)->System.out.println(a+"  : "+b));
		 List<Integer> values = Arrays.asList(2000, 5000, 8000, 3000);
		 
		Map map1= values.stream().collect(Collectors.groupingBy(a->a>5000));
		
		System.out.println("value greator than 5000 :"+map1.get(true));
		System.out.println("value less  than equal 5000 :"+map1.get(false));
		
	}

}
