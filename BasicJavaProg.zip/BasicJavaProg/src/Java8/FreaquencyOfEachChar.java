package Java8;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class FreaquencyOfEachChar {

	public static void main(String[] args) {

		String str = "vishal";
		
		
		Map map=Arrays.stream(str.split("")).collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
		
		map.forEach((a,b)->System.out.println(a+" : "+b));
		
	}

}
