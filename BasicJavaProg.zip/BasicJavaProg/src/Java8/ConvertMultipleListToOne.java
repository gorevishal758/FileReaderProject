package Java8;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ConvertMultipleListToOne {
	public static void main(String[] args) {

		List<List<String>> str=Arrays.asList(
				Arrays.asList("java","spring","sql"),
				Arrays.asList("python","mongo","nosql"),
				Arrays.asList("React","hooks","axios"));
		
		List l=str.stream().flatMap(aslist->aslist.stream()).collect(Collectors.toList());
		System.out.println(l);
        }
	
}
