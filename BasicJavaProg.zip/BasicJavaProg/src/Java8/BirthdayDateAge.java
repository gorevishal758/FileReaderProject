package Java8;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class BirthdayDateAge {
	public static void main(String[] args) {

		LocalDate birthday = LocalDate.of(2000, 03, 21);

		LocalDate curreDate = LocalDate.now();

		long age = ChronoUnit.YEARS.between(birthday, curreDate);

		System.out.println(age);

	}
}