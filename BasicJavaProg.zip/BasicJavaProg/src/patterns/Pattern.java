package patterns;

class Rectangle{
	
	public void rect() {
		int i,j;
		int n=4;
		int m=5;
		
		for(i=1 ;i<=n;i++) {
			
			for(j=1;j<=m	;j++) {
				
				if(i==1 || j==1 || i==n || j==m) {
					
					System.out.print("*");
				}else {
					
					System.out.print(" ");
				}
			}
			System.out.println();
		}
		
		
		
	}
	public void halfPyramid() {
		
		int i,j,n=4;
		
		
		for(i=1;i<=n ;i++) {
			
			for(j=1;j<=i;j++) {
				
					
					System.out.print("*");
				
				
			}
			System.out.println();
		}
	}
	
	public void invertParamyd() {
		
		
		int i,j,n=4;
		
		for(i=1;i<=n;i++) {
			
			for(j=n;j>=i;j--) {
				System.out.print("*");
			}
			System.out.println();
		}
		
	}
}
public class Pattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle r=new Rectangle();
		//hallow rectangle
		//r.rect();
		//half pyramid
		
		//r.halfPyramid();
		
		//invert pyramid
		r.invertParamyd();
		
		
	}

}
