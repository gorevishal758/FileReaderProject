package string;

public class FindFirstPalindromicStringInTheArray {

	public static void main(String[] args) {


		String[] words = {"abc","car","ada","racecar","cool"};
		String reverse;
		for(String word:words) {
			
			
			reverse=new StringBuilder(word).reverse().toString();
			
			if(word.equals(reverse)) {
				
				System.out.println(word);
				break;
			}
			
		
		}System.out.println("");

	}

}
