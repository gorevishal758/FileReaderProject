package string;

import javax.swing.AbstractAction;

interface Cde {

	int a = 12; //by default it is public static final

	public abstract void run();

	public abstract void run2();

	public default void start() {
		System.out.println("Abstact class method working  ");  // 1.8 v
	}

	public static void start1() {
		System.out.println("Abstact class method working  "); //1.8 v
	}
	private void start2() {
		System.out.println("Abstact class method working  "); //1.9 v
	}
}

abstract class Abc {

	public abstract void run();

	public abstract void run2();

	public Abc() {

		System.out.println("Abstact class constructor");
	}

	public void start() {
		System.out.println("Abstact class method working  ");
	}
}

class Single {

	private static Single single = new Single();

	private Single() {
		System.out.println("SingleTon constructor calling.........");
	}

	static Single getInstance() {

		return single;
	}

}

public class SingletonExample implements Cde {

	public static void main(String[] args) {

		Single sg = Single.getInstance();
		SingletonExample cde=new SingletonExample();
		
		System.out.println(cde.a);
	}

	@Override
	public void run() {
		System.out.println("Run calling...");
		
	}

	@Override
	public void run2() {
		System.out.println("Run2 calling...");
		
	}

}
