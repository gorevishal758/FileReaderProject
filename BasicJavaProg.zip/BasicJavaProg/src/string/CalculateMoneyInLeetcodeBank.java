package string;

public class CalculateMoneyInLeetcodeBank {

	public static void main(String[] args) {

	}

}
