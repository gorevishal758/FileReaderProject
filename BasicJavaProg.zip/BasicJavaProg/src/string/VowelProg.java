package string;


class Test{
	
	String s="vishal";
	int i,con,vol;
	
	
	public void test() {
		for(i=0 ;i<s.length();i++) {
			
			if(s.charAt(i)=='a' || s.charAt(i)=='e' || s.charAt(i)=='i'	|| s.charAt(i)=='o' || s.charAt(i)=='u' ) {
				
				vol++;
			}else
			{
				con++;
			}
		}
		System.out.println("volwel :"+vol);
		System.out.println("consonant :"+con);
	}
}

public class VowelProg {

	public static void main(String[] args) {

		String s = "vishal";
		String str = "";
		int i, count = 0,con=0;

		for (i = 0; i < s.length(); i++) {

	
			if (s.charAt(i) == 'a' || s.charAt(i) == 'e' || s.charAt(i) == 'i' || s.charAt(i) == 'o'
					|| s.charAt(i) == 'u') {

				count++;
				
			}
			else {
				
				con++;
				
			}
			
	}//System.out.println("Vowels  :"+count);
	//System.out.println("consonent :"+con);
		Test t=new Test();
		t.test();
	}
}
