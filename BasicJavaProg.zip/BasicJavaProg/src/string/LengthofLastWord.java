package string;

import java.util.Arrays;

public class LengthofLastWord {

	public static void main(String[] args) {

		String s = "Hello World gore";
		
		int i,count=0;
		
		String[] s1=s.split(" ");
		
		 String lastWord =s1[s1.length-1];
		 System.out.println(lastWord.length());
	}

}
