package string;

import java.util.Scanner;

public class Sol {

	public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Please enter number");
        int i = scan.nextInt();  
        System.out.println("Please enter Double");
        
        double d=scan.nextDouble();
        
         
        System.out.println("Please enter String  :"+scan.nextLine());
        String s = scan.nextLine();
        
        scan.close();
        System.out.println("String: "+s);
        System.out.println("Double: " + d);
        System.out.println("Int: " + i);
        
       
    }

}
