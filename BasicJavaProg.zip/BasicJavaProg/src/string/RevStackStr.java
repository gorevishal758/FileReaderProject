package string;

import java.util.Arrays;
import java.util.Stack;

public class RevStackStr {

	public static void main(String[] args) {

		String s="yash is technology";
		
		/*
		 * char c[]=s.toCharArray();
		 * 
		 * Arrays.sort(c);
		 * 
		 * String sort=new String(c); System.out.println(sort);
		 */

		String str ="";
		
		
		String[]  s1=s.split(" ");
		
		System.out.println(s1.length);
		
		for(int i=s1.length-1;i>=0;i--) {
			
		
			str=str+s1[i]+"  ";
			
		}System.out.println(str);
		
		
		
		
		
	}

}
