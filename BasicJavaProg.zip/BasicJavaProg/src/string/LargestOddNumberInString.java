package string;

public class LargestOddNumberInString {

	public static void main(String[] args) {


		String num1="6789	";
		String num2="4206";
		String num3="5793";
	
		
		if(Integer.parseInt(num1)%2 !=0) {
			
			System.out.println("Alreday odd");
		}
		
		String largOdd="";
		
		for(char c: num1.toCharArray()) {
			
			int digit=c-'0';

			if(digit %2 !=0) {
				
				largOdd+=c;
			}
		}
		System.out.println(largOdd.isEmpty() ? "" :largOdd);
	}

}
