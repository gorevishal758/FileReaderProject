package string;

public class Count_of_Matches_in_Tournament {

	public static void main(String[] args) {


		int n=9;
		int rem,sum=0;
		int res=0;
		while(n>1) {
			
			rem =n%2;
			n=n/2;
			res=n+rem;
			sum=sum+res;
			System.out.println(" result :"+sum);
			
		}

	}

}
