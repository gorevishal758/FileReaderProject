package string;

import java.util.ArrayList;

/*Write a program to find repeated words present in the below sentence?
String s ="India is a big country It is located near himalaya It is also located near nepal";*/
public class RepeatedWord {

	public static void main(String[] args) {
		
		String s ="India is a big country It is located near himalaya It is also located near nepal";
		
		int i,j,count;
		
		String words[]=s.split(" ");
		
		for(i=0 ;i<words.length;i++) {
			
			count=1;
			for(j=i+1 ;j<words.length;j++) {
				
				if(words[i].equals(words[j])) {
					
					count++;
					
					words[j]="0";
				}
				
				
			}if (count>=1 && words[i] !="0") {
				
				System.out.println(words[i]+" : "+count);
			}
		}
	    }  
	}  