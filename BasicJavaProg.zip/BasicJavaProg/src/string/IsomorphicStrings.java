package string;

import java.util.HashMap;
import java.util.Map;

public class IsomorphicStrings {

	public static void main(String[] args) {

		String s="dogf";
		String t="caty";
		
		 System.out.println(isIsomorphic(s, t));
	}

	
	
	
	    public static boolean isIsomorphic(String s, String t) {
	        if (s.length() != t.length()) {
	            return false;
	        }

	        HashMap<Character, Character> map = new HashMap<>();
	        HashMap<Character, Character> rmap = new HashMap<>();

	        for (int i = 0; i < s.length(); i++) {
	            char c1 = s.charAt(i);
	            char c2 = t.charAt(i); // Corrected to reference character from string 't'
	            if (map.containsKey(c1)) {
	                if (map.get(c1) != c2) {
	                    return false;
	                }
	            } else {
	                if (rmap.containsKey(c2)) {
	                    return false;
	                }
	                map.put(c1, c2);
	                rmap.put(c2, c1);
	            }
	        }
	        return true;
	    }
	}

