package string;

public class LongestEvenString {

	public static void main(String[] args) {
		String str = "a group of words containing a subject and a verb, that expresses a statement, a question";
		
		String[] words=str.split(" ");
		String word=null;
		for(String s:words) {
			
			if(s.length() %2==0) {
				
				if(word==null ||s.length() >word.length()) {
					
					word=s;
		
					
					
				}
			}
		}			System.out.println(word);

	}

}
