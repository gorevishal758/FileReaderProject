package string;

import java.util.Scanner;

class ForDemo {

	//String s="";
	String str ="" ;
	
	
	public void forDemo() {

		Scanner sc=new Scanner(System.in);
		
		System.out.println("Please enter a string   :");
		
		String s=sc.nextLine();
		
		System.out.println("Enter string is   :"+s);
	for(
	int i = s.length() - 1;i>=0;i--)
	{

		str = str + s.charAt(i);

	}
	
	if(str.equals(s))
	{

		System.out.println("is palindrome  :"+str);
	}else
	{
		System.out.println("not palindrome  :"+str);
	}
	}

}

class WhileDemo{
	
	
	public void whileDemo() {
		
		String s="vishal",str="";  
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Please Enter string   :");
		
		String s1=sc.nextLine();
		
		System.out.println("Enter string is    :"+s1);
		 
		int i =s.length();
		while(i >0) {
			
			i--;
			str=str+s.charAt(i);
		}
	System.out.println("Reverse string is    :"+str);
	}
	
	
}

class StrLen{
	
	
	String str="vishal";
	int len=0;
	
	public void len() {
		
		for(char c:str.toCharArray()) {
			
			len++;
			
		}
		System.out.println(len);
	}
}

class Concat {
	String s1="v",s2="i",res;
	
	public void conc() {
		
		Scanner sc =new Scanner(System.in);
		System.out.println("Please Enter a string 1  :");
		s1=sc.nextLine();
		System.out.println("Enter string 1 is  :"+s1);
		
		s2=sc.nextLine();
		System.out.println("Enter string 1 is  :"+s2);
		
		System.out.println(s1.concat("   "+s2));
	}
	
}

public class ReverseString {

	public static void main(String[] args) {
		
		ForDemo d=new ForDemo();
		
		//d.forDemo();
		
		
		WhileDemo w=new WhileDemo();
		//w.whileDemo();

		StrLen s=new StrLen();
		//s.len();
		
		Concat c=new Concat();
		//c.conc();
		
		String s3="vishal";
		
		int i;
		String str = "";
		
		for(i=s3.length()-1 ;i>=0;i--) {
			
			str=str+s3.charAt(i);
			
		}
		
		System.out.println(str);
}
}
