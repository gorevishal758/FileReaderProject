package string;

import java.util.Arrays;

public class Largest_3_Same_Digit_Number_in_String {

	public static void main(String[] args) {


		String num = "222";
		String maxGoodInteger = "";
		for (int i=0 ;i<num.length()-2 ;i++) {
			
			String substring =num.substring(i, i+3);
			//System.out.println(substring);
			
			if(num.charAt(i) ==num.charAt(i+1) && num.charAt(i+1)==num.charAt(i+2)) {
				
				if(maxGoodInteger.isEmpty() || substring.compareTo(maxGoodInteger) >0) {
					
					maxGoodInteger=substring;
					
					
					
					
				}
			} 
		}
	System.out.println("Input   :"+num);
	System.out.println("Output  :"+(maxGoodInteger.isEmpty() ?"Not found ":maxGoodInteger));
		


	}

}
