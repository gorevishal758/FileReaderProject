package string;

import java.util.Arrays;

public class AnagramProg {

	public static void main(String[] args) {

		String s1 = "vishal";
		String s2 = "ishval";

		char c1[] = s1.toCharArray();
		char c2[] = s2.toCharArray();

		int len1 = s1.length();
		int len2 = s2.length();

		if (len1 == len2) {

			Arrays.sort(c1);
			Arrays.sort(c2);

			if (Arrays.equals(c1, c2)) {
				{

					System.out.println("Anagram");
				}

			} else {
				System.out.println("Not Anagram");
			}

		}

	}
}
