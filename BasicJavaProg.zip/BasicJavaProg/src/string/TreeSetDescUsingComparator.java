package string;

import java.util.Comparator;
import java.util.TreeSet;

class MyComparator implements Comparator {

	@Override
	public int compare(Object o1, Object o2) {

		Integer I1 = (Integer) o1;
		Integer I2 = (Integer) o2;

		return -I1.compareTo(I2);
	}

}

public class TreeSetDescUsingComparator {

	public static void main(String[] args) {

		TreeSet<Integer> t = new TreeSet<>(new MyComparator());
			t.add(2);
			t.add(5);
			t.add(1);
			t.add(10);
			
			System.out.println(t);
	}

}
