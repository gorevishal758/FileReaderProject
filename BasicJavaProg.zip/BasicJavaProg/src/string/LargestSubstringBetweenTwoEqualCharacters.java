package string;

public class LargestSubstringBetweenTwoEqualCharacters {

	public static void main(String[] args) {

		String s = "cabbac";
		
		int max=-1;
		for(int i=0;i<s.length();i++) {
			
			char c=s.charAt(i);
		
			int len=s.lastIndexOf(c);
			
			
			if(len !=i) {
				int cIndex=len-i-1;
				
				if(cIndex >max) {
					
					max=cIndex;
				}
			}
			
		}System.out.println(max);
	}

}
