package string;

public class StringImp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str1 = "Java";
		 String str2 = "Java";
		 String str3 = new String("Java");

		 System.out.println(str1 == str2); 
		 System.out.println(str1 == str3); 
		 System.out.println(str1.equals(str3));
		 
		 String s1 = "Hello";
		 String s2 = new String("Hello");
		 System.out.println(s1==s2);
		 
		 String s=null;
		 System.out.println(s.length());

	}

}
