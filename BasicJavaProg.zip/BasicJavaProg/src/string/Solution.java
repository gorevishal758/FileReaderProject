package string;

import java.util.*;

public class Solution {
    public static int absoluteDifferenceTypeAtypeB(int arrayLength, List<Integer> arr) {
        int typeACount = 0;
        int typeBCount = 0;
 
        for (int i = 0; i < arrayLength - 1; i++) {
            int length = arr.get(i);
            int width = arr.get(i + 1);
 
            int area = length * width;
            int perimeter = 2 * (length + width);
 
            if (area > perimeter) {
                typeACount++;
            } else if (area < perimeter) {
                typeBCount++;
            }
        }
 
        return Math.abs(typeACount - typeBCount);
    }
 
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int arrayLength = Integer.parseInt(scan.nextLine().trim());
        List<Integer> arr = new ArrayList<>();
 
        for (int j = 0; j < arrayLength; j++) {
            arr.add(Integer.parseInt(scan.nextLine().trim()));
        }
 
        int result = absoluteDifferenceTypeAtypeB(arrayLength, arr);
        System.out.println("Absolute difference = " + result);
        
        scan.close();
    }
}