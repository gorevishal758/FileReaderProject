package string;

public class Demo_Int {

	public static void main(String[] args) {

		String str = "java is good programming lang ";

		char[] charArr = str.toCharArray();

		int[] count = new int[1000];

		for (int i = 0; i < charArr.length; i++) {

			// char c=
			char c = str.charAt(i);

			if (Character.isLetter(c)) {

				count[c]++;

			}
		}

		for (int j = 0; j < count.length; j++) {

			if (count[j] > 0) {
				char letter = (char) j;
				System.out.println(letter + "  : " + count[j]);

			}

		}

	}

}
