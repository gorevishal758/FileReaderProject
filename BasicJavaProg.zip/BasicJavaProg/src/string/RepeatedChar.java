package string;

class SenRep{
	
	String s="vishal gore is is vishal";
	
	String c[]=s.split(" ");
	int i,j,count;
	
	public void test() {
		
		for(i=0;i<c.length;i++) {
			
			count=1;
			
			for(j=i+1;j<c.length;j++) {
				
				if(c[i].equals(c[j])) {
					
					count++;
					
					c[j]="0";
					
					
				}
			}
			
			if(count >1 && c[i] !="0") {
				
				System.out.println(c[i]+"  "+count);
			}
		}
	}
}

class CharRep{
	
	String s="abbcbba";
	
	String c[]=s.split("");
	int i,j,count;
	
	public void rep() {
		
		for(i=0;i<c.length;i++) {
			count=1;
			for(j=i+1;j<c.length;j++) {
				
				
				if(c[i].equals(c[j])) {
					
					count++;
					
					c[j]="0";
					
				}
			}
			
			if(count >1 && c[i] !="0")
			{
				System.out.println(c[i]+" "+count);
			}
		}
	}
	
	
}

public class RepeatedChar {

	public static void main(String[] args) {

		String s="abbbccccc";
		
		int i,j,count;
		
		String c[]=s.split("");
		
		
		for(i=0 ;i<=c.length;i++) {
			
			count =1;
			
			for(j=i+1 ;j<c.length ; j++) {
				
				
				if(c[i].equals(c[j])) {
					
					count++;
					
					c[j]="0";
				}
			}
			if(count>1  && c[i] !="0") {
				
			
				//System.out.println(c[i]+" : "+count);
			
			}
		}
		
		CharRep c1=new CharRep();
		//c1.rep();
		
		SenRep sr=new SenRep();
		
		//sr.test();

	}

}
