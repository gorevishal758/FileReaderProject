package string;

public class SplitString {

	public static void main(String[] args) {

		String str = "vishal,ram,shyam";
		int count=0;
		for(int i=1;i<str.length()-1;i++) {
			
			if(str.charAt(i)==',') {
				
				++count;
			}
			
		}
		  int numberOfWords = count + 1;
		System.out.println(numberOfWords);

	}

}
