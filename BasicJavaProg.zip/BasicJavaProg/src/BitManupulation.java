import java.util.Scanner;

public class BitManupulation {
	
	
	public void get() {
		
		//process make bitmask then perform operation with & operator 
		int n=5;
		
		int pos=3;
		int bitmask= 1<<pos;
		
		if((bitmask & n)==0) {
			
			System.out.println("bit is zero");
		}
		else {
			System.out.println("bit is one");
		}
	}
	public void set() {
		
		int n=5;
		int pos=1;
		int bitmask= 1<<pos;
		
		int res=bitmask |n;
		System.out.println(res);
		 
		String s1=Integer.toBinaryString(res);
		String s2=Integer.toBinaryString(n);
		System.out.println(s1);
		System.out.println(s2);
		
	}
	
	//clear the 3rd bit(pos 2) of number n(n=0101);
	
	public void clear() {
		
		int n=5;
		int pos=2;
		int bitmask=1<<pos;
		int not=~bitmask;
		int res=(not &n);
	System.out.println(res);	
	
	String s1=Integer.toBinaryString(res);
	String s2=Integer.toBinaryString(n);
	System.out.println(s1);
	System.out.println(s2);
	}

	public void update() {
		
		//update 2nd bit (pos=1)of n to1 (n=0101)
		
		// if opration 1 then set 
		// if operation 0 then use clear
		
		Scanner sc=new Scanner(System.in);
		
		int opeartion=sc.nextInt();
		
		int n=5; 
		int pos=1;
		int bitmask=1<<pos;
		
		
		if(opeartion==1) {
			
			int res1=bitmask |n;
			
			System.out.println(res1);
			
		}
		else {
			 int res2= (~bitmask)&n;
			 System.out.println(res2);
		}
	}
	public static void main(String[] args) {

		BitManupulation b=new BitManupulation();
		b.update();

		

	}

}
