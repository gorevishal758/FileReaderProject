package recursion;

public class PrintNum {

	public static void printNum(int num) {
		
		if(num==0) {
			return;
		}
		System.out.println(num);
		printNum(num-1);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=5;
		printNum(num);
	}

}
