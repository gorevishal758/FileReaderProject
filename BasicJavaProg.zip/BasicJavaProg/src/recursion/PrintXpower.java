package recursion;

public class PrintXpower {
	
	public static int power(int x, int n) {
		
		
		if(x==0) {
			return 0;
		}
		if(n==0) {
			
			return 1;
		}
		int xpower=power(x,n-1);
		
		int result_power=x*xpower;
		
		return result_power;
		
	}

	public static void main(String[] args) {


		int result=power(2, 4);
		System.out.println(result);

	}

}
