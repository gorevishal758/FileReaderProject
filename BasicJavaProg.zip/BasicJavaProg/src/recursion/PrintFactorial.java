package recursion;

public class PrintFactorial {

	public static int fact(int n) {
		
		if(n==1 ||n==0) {
			
			return 1;
		}
		int factorial=fact(n-1);
		int factorial_result= n*factorial;
		
		return factorial_result;
		
		
	}
	public static void main(String[] args) {
		
		int result=fact(0);
		System.out.println(result);
	}

}
