package comparatorAndComparable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ComparatorExampleId implements Comparator<Student> {

	@Override
	public int compare(Student o1, Student o2) {

		if (o1.getId() == o2.getId()) {

			return 0;
		} else if (o1.getId() > o2.getId()) {

			return 1;
		} else
			return -1;
	}

	public static void main(String[] args) {
		Student e1 = new Student(9, "vishal");
		Student e5 = new Student(1, "vishal");
		Student e2 = new Student(4, "ram");
		Student e3 = new Student(3, "syam");
		Student e4 = new Student(2, "jivan");

		List<Student> student = new ArrayList<>();
		student.add(e1);
		student.add(e2);
		student.add(e3);
		student.add(e4);
		student.add(e5);
		Collections.sort(student, new CompatorByNameThenId());
		System.out.println(student);

	}

}
