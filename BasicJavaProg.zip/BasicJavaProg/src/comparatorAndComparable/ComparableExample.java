package comparatorAndComparable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ComparableExample implements Comparable<ComparableExample> {
	private int id;
	private String name;

	public ComparableExample(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public int compareTo(ComparableExample o) {

		if (id == o.id) {

			return 0;
		} else if (id > o.id) {

			return 1;
		} else  {

			return -1;
		}

	}

	@Override
	public String toString() {
		return "ComparableExample [id=" + id + ", name=" + name + "]";
	}

	public static void main(String[] args) {

		ComparableExample e1=new ComparableExample(1,"vishal");
		
		ComparableExample e2=new ComparableExample(4,"ram");
		ComparableExample e3=new ComparableExample(3,"syam");
		ComparableExample e4=new ComparableExample(2,"jivan");
		
		List<ComparableExample> list=new ArrayList<>();
		list.add(e1);
		list.add(e2);
		list.add(e3);
		list.add(e4);
		Collections.sort(list);
		System.out.println(list);
	}

	

}
