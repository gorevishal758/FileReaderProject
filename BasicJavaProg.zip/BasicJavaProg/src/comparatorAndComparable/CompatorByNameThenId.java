package comparatorAndComparable;

import java.util.Comparator;

public class CompatorByNameThenId implements Comparator<Student>{

	@Override
	public int compare(Student o1, Student o2) {
		
		  int nameComparison = o1.getName().compareTo(o2.getName());
		  
		  if(nameComparison==0) {
			  
			  return Integer.compare(o1.getId(),o2.getId());
		  }else {
			  return nameComparison;
		  }
	}

}
