package streamapi;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class CountOfEachCharacterInString {

	public static void main(String[] args) {
		String s ="string data to count each character";
		

		
		Arrays.stream(s.split("")).filter(x->!x.equals(" "))
		.collect(Collectors.groupingBy(Function.identity(),
				LinkedHashMap::new,Collectors.counting()))
		.forEach((x,y)->System.out.println(x+":"+y));
		
		
	
		
	}

}
