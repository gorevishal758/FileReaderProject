package streamapi;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

public class ValueAppearsAtLeastTwice {

	public static void main(String[] args) {

		int[] nums = { 1, 2, 3, 1 };

		List<Integer> list = Arrays.stream(nums).boxed().collect(Collectors.toList());

		HashSet<Integer> set = new HashSet<>(list);

		if (list.size() == set.size()) {

			System.out.println(false);
		} else
			System.out.println(true);

	}

}
