package streamapi;

import java.util.Arrays;

public class MaxElementInArray {

	public static void main(String[] args) {

		int[] max = { 12, 19, 20, 88, 00, 9 };
		
Integer in=Arrays.stream(max).max().getAsInt();
System.out.println(in);
	}

}
