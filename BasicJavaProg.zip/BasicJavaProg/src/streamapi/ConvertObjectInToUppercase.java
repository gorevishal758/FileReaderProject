package streamapi;

import java.util.Arrays;

public class ConvertObjectInToUppercase {

	public static void main(String[] args) {

		String[] str= {"aa","bb","cc"};
		
		Arrays.stream(str).map(x->x.toUpperCase()).forEach(System.out::println);
	}

}
