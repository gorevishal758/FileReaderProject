import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Supplier;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class HashMapQue {

	public static void main(String[] args) {
		
		HashMap<Integer,String> map=new HashMap<>();
		map.put(1, "vishal");
		map.put(5, "Hari");
		map.put(4, "Ram");
		map.put(2, "shyam");
		
		
		
			map.entrySet().stream()
			.sorted(Map.Entry.comparingByKey()).toList();
			
			
		
		

	}

}
