package arrays;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;



class Employee {

	private int id;
	private String name;
	private String location;

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(int id, String name, String location) {
		super();
		this.id = id;
		this.name = name;
		this.location = location;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getLocation() {
		return location;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", location=" + location + "]";
	}

}

public class EmployeeStreamApiSort {
	public static void main(String[] args) {

		// Write Java Program to find all the employees in sorted order from pune
		// location using stream api from an Arraylist.

		List<Employee> l = new ArrayList<>();

		l.add(new Employee(1, "chiru", "pune"));
		l.add(new Employee(3, "vishal", "wardha"));
		l.add(new Employee(5, "chiran", "pune"));
		l.add(new Employee(6, "jagan", "shyampur"));
		l.add(new Employee(7, "ram", "pune"));

		l.stream().filter(e -> "pune".equalsIgnoreCase(e.getLocation())).sorted(Comparator.comparing(Employee::getName))
				.collect(Collectors.toList()).forEach(x -> System.out.println(x));
	}
}
