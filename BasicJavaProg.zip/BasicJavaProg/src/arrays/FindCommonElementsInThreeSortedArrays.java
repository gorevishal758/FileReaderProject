package arrays;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FindCommonElementsInThreeSortedArrays {

	public static void main(String[] args) {

		int[] a1 = { 1, 2, 4, 5, 6, 6 };

		int[] a2 = { 3, 4, 8, 9, 6 };

		int[] a3 = { 11, 12, 13, 14, 6 };
		
		Arrays.sort(a1);
		Arrays.sort(a2);
		Arrays.sort(a3);
		
		int x = 0, y = 0, z = 0;
		List<Integer> list = new ArrayList<>();
		while (a1.length > x && a2.length > y && a3.length > z) {

			if (a1[x] == a2[y] && a2[y] == a3[z]) {

				list.add(a1[x]);

				x++;
				y++;
				z++;
			} else if (a1[x] < a2[y]) {
				x++;
			} else if (a2[y] < a3[z]) {
				y++;
			} else {
				z++;
			}
		}

		for(int m:list) {
			System.out.println(m);
		}
		

	}

}
