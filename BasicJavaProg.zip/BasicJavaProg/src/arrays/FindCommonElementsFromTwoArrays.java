package arrays;

import java.util.HashSet;
import java.util.Set;

public class FindCommonElementsFromTwoArrays {

	public static void main(String[] args) {

		int[] a1 = { 1, 2, 4, 5, 6, 6 };

		int[] a2 = { 3, 4, 8, 9, 6 };

		Set<Integer> set = new HashSet<>();

		for (int i = 0; i < a1.length; i++) {

			for (int j = 0; j < a2.length; j++) {

				if (a1[i] == a2[j]) {

					set.add(a1[i]);
					break;
				}
			}
		}
		for (int n : set) {
			System.out.println("Common element in two array : " + n);
		}
		
		//using collection framework
		for(int a:a1) {
			
			set.add(a);
		}
		for(int b:a2) {
			if(set.add(b)==false) {
				System.out.println("Common element in two array : " + b);
			}
		}
	}

}
