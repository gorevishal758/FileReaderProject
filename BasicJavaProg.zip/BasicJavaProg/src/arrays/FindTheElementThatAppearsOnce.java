package arrays;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.function.Function;
import java.util.stream.Collectors;

public class FindTheElementThatAppearsOnce {

	public static void main(String[] args) {


		int[] num= {1,2,4,3,1,4,2,3,8};
		int res=num[0];
		for(int i=1;i<num.length;i++) {
			
			res=res^num[i];
		}System.out.println("Single elements found to be : "+res);
		
		//By using stream api
		
		Arrays.stream(num).boxed().collect(Collectors.groupingBy(
				
				Function.identity(),LinkedHashMap::new,Collectors.counting()
				)).entrySet().stream().filter(value->value.getValue() ==1L).map(key->key.getKey()).forEach(x->System.out.println(x));

	}

}
