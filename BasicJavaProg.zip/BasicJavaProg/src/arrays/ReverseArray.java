package arrays;

import java.util.Arrays;
import java.util.stream.IntStream;

public class ReverseArray {

	public static void main(String[] args) {
		
		int[] arr= {1,6,7,8,9,0,2};
		
		int[] res=IntStream.rangeClosed(1, arr.length).map(i->arr[arr.length-i]).toArray();
		
		System.out.println(Arrays.toString(res));
		
		int n=arr.length;
		 for (int i = 0; i < n / 2; i++) {
	           int temp=arr[i];
	           arr[i]=arr[n-i-1];
	           arr[n-i-1]=temp;
	        }
		 System.out.println(Arrays.toString(arr));
	}

}
