package arrays;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class EvenOdd {

	public static void main(String[] args) {
		int[] num= {1,4,5,6,8,11,13};
		
	List<Integer> even=new ArrayList<>();
	List<Integer> odd=new ArrayList<>();
	
	
	for(int n:num) {
		
		if(n%2==0) {
			
			even.add(n);
		}else {
			
			odd.add(n);
		}
	}
	for(int no:even) {
		System.out.println("Even :"+even);
		break;
	}
	for(int no:odd) {
		System.out.println("Odd :"+odd);
		break;
	}
	
	System.out.println("count of even : "+even.size());
	System.out.println("count of odd : "+odd.size());
	}

}
