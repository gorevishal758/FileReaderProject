package arrays;

public class FindMissingNumberInArray {

	public static void main(String[] args) {

		int[] n = { 1, 2, 3, 4, 5, 6, 8,10 };
		int diff = 0;
		int exp_no = n.length + 1;

		int total_sum = exp_no * (exp_no + 1) / 2;
		int orginal_sum = 0;

		for (int i = 0; i < n.length; i++) {

			orginal_sum += n[i];
		}

		System.out.println("Missing number :" + (total_sum - orginal_sum));

		// using x-or

		int res = n[0];
		int res1 = 1;
		for (int i = 1; i < n.length; i++) {

			res = res ^ n[i];
		}
		for (int i = 2; i <= n.length + 1; i++) {
			res1 = res1 ^ i;
		}

		int num = res ^ res1;

		System.out.println("Missing element is :" + num);
		
		//using for loop with diff
		
		
		
		for(int i=0;i<n.length-1;i++) {
			
			diff=n[i+1]-n[i];
			if (n[i] >= 0 && diff > 1) {

				System.out.println(n[i] + 1);

			}
		}

	}

}
