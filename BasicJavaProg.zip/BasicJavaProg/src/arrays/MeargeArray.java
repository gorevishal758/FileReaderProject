package arrays;

public class MeargeArray {

	public static void main(String[] args) {

		int[] a1 = { 1, 2, 5 };
		int[] a2 = { 4, 5, 6 };

		int c = a1.length + a2.length;
		int[] c1 = new int[c];

		for (int i = 0; i < a1.length; i++) {

			c1[i] = a1[i];
		}
		for (int i = 0; i < a2.length; i++) {

			c1[a1.length+i] = a2[i];
		}
		
		for(int i=0;i<c1.length;i++) {
			System.out.println(c1[i]);
		}

	}

}
