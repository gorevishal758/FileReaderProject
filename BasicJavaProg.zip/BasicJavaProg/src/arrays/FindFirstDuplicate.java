package arrays;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

public class FindFirstDuplicate {

	public static void main(String[] args) {
		
		int[] num= {9,10,9,8,4,5,6,7,4,8,8};
		int flag=0;
		
		for(int i=0;i<num.length;i++) {
			
			for(int j=i+1;j<num.length;j++) {
				
				if(num[i]==num[j] && i!=j) {
					
					System.out.println("First Duplicate element : "+num[i]);
					flag+=1;
					break;
				}
				
			} if(flag>0) {
			
				break;
			}
		}
		
		
		//By using Collection
		Set<Integer> set=new HashSet<>();
		
		for(int i:num) {
			
			if(set.add(i)==false) {
				
				System.out.println("First Duplicate element found to be : "+i);
				break;
			}
		}

		//By using stream api
		
		int i=Arrays.stream(num).boxed().collect(Collectors.groupingBy(
				
				Function.identity(),LinkedHashMap::new,Collectors.counting()
				
				)).entrySet().stream().filter(x->x.getValue() >1L).map(y->y.getKey()).findFirst()
		.get();
		System.out.println("First Duplicate element found to be :"+i);
	}

}
