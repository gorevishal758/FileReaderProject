package arrays;

import java.util.Arrays;
import java.util.Comparator;

public class SecondLargest {

	public static void main(String[] args) {
		int[] arr= {1,6,7,8,9,0,2};

		int r=Arrays.stream(arr).boxed().sorted(Comparator.reverseOrder()).skip(1).findFirst().get();
		System.out.println(r);
		
		
		int Largest=Integer.MIN_VALUE;
		int secondLargest=Integer.MAX_VALUE;
		
		for(int num:arr) {
			
			if(num> Largest) {
				
				secondLargest=Largest;
				Largest=num;
			}
			else if(num >secondLargest && num !=Largest) {
				
				secondLargest=num;
			}
		}
		System.out.println("Second largest element: " + secondLargest);	
	}

}
