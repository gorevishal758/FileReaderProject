package arrays;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.IntStream;

public class MergeTwoArrays {

	public static void main(String[] args) {

		int[] num1 = { 1, 2, 3, 4, 8, 9, 10, 5, 6 };
		int[] num2 = { 20, 21, 22, 23 };

		int len_num1 = num1.length;
		int len_num2 = num2.length;
		int len_res = len_num1 + len_num2;

		int[] res = new int[len_res];

		for (int i = 0; i < len_num1; i++) {

			res[i] = num1[i];
		}

		for (int i = 0; i < len_num2; i++) {

			res[len_num1+i] = num2[i];
		}
		for(int x:res) {
			
			System.out.print(x+" ");
		}
		
		//Stream api
		System.out.println();
		System.out.println("By using stream api ");
		
		int[] result=IntStream.concat(Arrays.stream(num1), Arrays.stream(num2)).toArray();
		System.out.println(Arrays.toString(result));
	}

}
