package immutableClass;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public final class Student {

	private final String name;
	private final Date doj;
	private final List<String> mobile;
	private final Address address;

	public Student(String name, Date doj, List<String> mobile,Address address) {
		super();
		this.name = name;
		this.doj = doj;
		this.mobile = mobile;
		this.address = address;
	}

	public String getName() {
		return name;
	}

	public Date getDoj() {
		return (Date) doj.clone();
	}

	public List<String> getMobile() {
		return new ArrayList<>(mobile);
	}

	
	public Address getAddress() {
		return new Address(address.getAdd(),address.getPincode());
	}
	
	

	@Override
	public String toString() {
		return "Student [name=" + name + ", doj=" + doj + ", mobile=" + mobile + ", address=" + address + "]";
	}

	public static void main(String args[]) {
		Address address=new Address("wardha",442001);
		Student student=new Student("vishal",new Date(),Arrays.asList("123","456","678"),address);
		
		
		student.getDoj().setDate(20);
		student.getMobile().add("999");
		student.getAddress().setPincode(1234);
		System.out.println(student);
	}
}
