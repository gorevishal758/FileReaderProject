package immutableClass;

public class Address {

	private String add;
	private int pincode;

	public Address(String add, int pincode) {
		super();
		this.add = add;
		this.pincode = pincode;
	}

	public String getAdd() {
		return add;
	}

	public void setAdd(String add) {
		this.add = add;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	@Override
	public String toString() {
		return "Address [add=" + add + ", pincode=" + pincode + "]";
	}

}
