package practice;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class HashAndEquals {

	private int id;
	private String name;
	
	
	public HashAndEquals(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}


	@Override
	public int hashCode() {
		return Objects.hash(id, name);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HashAndEquals other = (HashAndEquals) obj;
		return id == other.id && Objects.equals(name, other.name);
	}


	@Override
	public String toString() {
		return "Test3 [id=" + id + ", name=" + name + "]";
	}


	public static void main(String[] args) {
		HashAndEquals t1=new HashAndEquals(1,"vishal");
		HashAndEquals t2=new HashAndEquals(1,"vishal");
		
		Map<HashAndEquals,String> map=new HashMap<>();
		
		map.put(t1,"yes");
		map.put(t2,"no");
		
		System.out.println(map);
	}

}
