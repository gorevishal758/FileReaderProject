package practice;

class SingleTon{
	
	private static final SingleTon single = new SingleTon();
	
	private SingleTon() {
		System.out.println("working");
	}
	
	public static SingleTon getInstance() {
		
		
		return single;
	}
	
}
public class PracticeQue{

	public static void main(String[] args) {
		
	
	}

}
