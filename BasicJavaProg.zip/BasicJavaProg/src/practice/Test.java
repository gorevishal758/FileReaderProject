package practice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Test {

	public static void main(String[] args) {

		
		
		List<String> oneList = List.of("hello", "bad", "world","vishal","hello");
        List<String> twoList = List.of("c", "hello", "world", "wed","vishal");
 
        List<String> result = getSameElement(oneList, twoList);
 
        System.out.println(result); // Output: [hello, world]

	}

	public static List<String> getSameElement(List<String> oneList, List<String> twoList) {
		
		Set<String> set=new HashSet<String>(oneList);
		List<String> result=new ArrayList<>();
		
		for(String element:twoList) {
			
			if(set.contains(element)) {
				
				result.add(element);
			}
		}
		
		return result;
	}
}