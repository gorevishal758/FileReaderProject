package com.edi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReadEdIfileapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
