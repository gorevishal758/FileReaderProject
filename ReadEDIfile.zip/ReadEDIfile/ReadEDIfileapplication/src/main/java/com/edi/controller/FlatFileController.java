package com.edi.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class FlatFileController {

	@PostMapping("/upload")
	public String handleFileUpload(@RequestParam("file") MultipartFile file, Model model) {
	    if (!file.isEmpty()) {
	        try (BufferedReader reader = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
	            List<String> contentList = new ArrayList<>();
	            String line;
	            boolean isFlatFile = false;

	            while ((line = reader.readLine()) != null) {
	                String[] values = line.split("\\|");

	                boolean isFlat1 = line.startsWith("100") ;
	                
	                boolean isFlat0 = line.startsWith("000") ;

	                if (isFlat1) {
	                    isFlatFile = true;

	                    if (values.length > 1) {
	                        String partnerCode = values[1];
	                        String status = values[2];
	                        String loadNumber = values[5];
	                        String shipmentId = values[15];
	                        String mode = values[40];
							/* String oceanBOL = values[85]; */

	                        contentList.add("PartnerCode  :- " + partnerCode);
	                        contentList.add("Status: " + status);
	                        contentList.add("Load Number  :- " + loadNumber);
	                        contentList.add("Container Number: " + shipmentId);
	                        // contentList.add("Mode :- " + mode);
	                        // contentList.add("OceanBOL :- " + oceanBOL);
	                    }
	                }
	                
	                if (isFlat0) {
	                    isFlatFile = true;

	                    if (values.length > 1) {
	                        String tran = values[1];
	                       
							/* String oceanBOL = values[85]; */

	                        contentList.add("Transaction Type :- " + tran);
	                      
	                    }
	                }
	            }

	            model.addAttribute("content", contentList);
	            model.addAttribute("isFlatFile", isFlatFile);
	            model.addAttribute("message", isFlatFile ? "File uploaded successfully." : null);
	        } catch (IOException e) {
	            model.addAttribute("message", "Error occurred while processing the file.");
	        }
	    } else {
	        model.addAttribute("message", "Please select a file to upload.");
	    }

		return "index";
	}

}
