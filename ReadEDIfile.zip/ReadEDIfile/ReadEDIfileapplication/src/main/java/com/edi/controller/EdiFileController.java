package com.edi.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class EdiFileController {
	@PostMapping("/ediupload")
	public String handleFileUpload(@RequestParam("file") MultipartFile file, Model model) {
	    if (!file.isEmpty()) {
	        try (BufferedReader reader = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
	            List<String> contentList = new ArrayList<>();
	            String line;
	            boolean isEdiFile = false;

	            while ((line = reader.readLine()) != null) {
	                String[] values = line.split("\\*");

	                boolean isEdi = line.startsWith("ISA");

	                if (isEdi) {
	                    isEdiFile = true;

	                    if (values.length > 1) {
	                        String senderQualifier = values[5];
	                        String senderId = values[6];
	                        String receiverQualifier = values[7];
	                        String receiverId = values[8];
	                        String usageIndicator = values[15];

	                        contentList.add("Sender ID Qualifier: " + senderQualifier);
	                        contentList.add("Sender ID: " + senderId);
	                        contentList.add("Receiver ID Qualifier: " + receiverQualifier);
	                        contentList.add("Receiver ID: " + receiverId);
	                        contentList.add("Usage Indicator: " + usageIndicator);
	                    }
	                }

	                if (line.startsWith("GS")) {
	                    if (values.length > 1) {
	                        String functionalCode = values[1];

	                        contentList.add("Functional Id code: " + functionalCode);
	                    }
	                }

	                if (line.startsWith("ST")) {
	                    if (values.length > 1) {
	                        String transactionCode = values[1];

	                        contentList.add("Transaction Code: " + transactionCode);
	                        
	                    }
	                }
	                if (line.startsWith("BEG")) {
	                    if (values.length > 1) {
	                        String purchaseOrder = values[3];

	                        contentList.add("Purchase Order: " + purchaseOrder);
	                       break;
	                    }
	                }
	            }

	            model.addAttribute("content1", contentList);
	            model.addAttribute("isEdiFile", isEdiFile);
	            model.addAttribute("message1", isEdiFile ? "EDI file uploaded successfully." : null);
	        } catch (IOException e) {
	            model.addAttribute("message1", "Error occurred while processing the file.");
	        }
	    } else {
	        model.addAttribute("message1", "Please select a file to upload.");
	    }

	    return "index";
	}
}