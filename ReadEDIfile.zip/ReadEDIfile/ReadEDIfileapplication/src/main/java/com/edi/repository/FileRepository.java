package com.edi.repository;

public interface FileRepository {

	
}
