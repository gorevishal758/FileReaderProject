package com.edi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReadEdIfileapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReadEdIfileapplicationApplication.class, args);
	}

}
