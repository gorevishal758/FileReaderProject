package com.edi.model;

public class FlatFile {

}
