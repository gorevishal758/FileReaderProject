//package com.bank.config;
//
//import org.springframework.context.annotation.ComponentScan;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;
//import org.springframework.web.servlet.view.InternalResourceViewResolver;
//import org.springframework.web.servlet.view.JstlView;
//@Configuration
//@ComponentScan(basePackages = {"com.bank"})
//public class AppConfig extends WebMvcConfigurationSupport{
//
//	public InternalResourceViewResolver viewResolver() {
//		
//		InternalResourceViewResolver jspViewResolver =new InternalResourceViewResolver();
//		jspViewResolver.setPrefix("/jsp/");
//		jspViewResolver.setSuffix(".jsp");
//		jspViewResolver.setViewClass(JstlView.class);
//		
//		return jspViewResolver;
//		
//	}
//}
