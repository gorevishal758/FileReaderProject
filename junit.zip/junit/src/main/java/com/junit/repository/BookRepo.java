package com.junit.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.junit.Entity.Book;

public interface BookRepo extends JpaRepository<Book,Long> {

}
