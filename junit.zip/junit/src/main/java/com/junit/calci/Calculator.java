package com.junit.calci;

public class Calculator {

	public int addition(int a,int b) {
		
		return  a+b;
	}
}
