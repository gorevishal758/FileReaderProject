package com.junit;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class JunitExampleTest {

	@Test
	public void demoTestMethod() {
	
		assertTrue(true);
	}
}
