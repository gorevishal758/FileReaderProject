package com.junit;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.junit.calci.Calculator;

public class CalculatorTest {

	Calculator calculator;
	
	@BeforeEach
	void setUp() {
		
		calculator =new Calculator(); 
	}
	
	@Test
	public void testAddition() {
		
		int expected =20;
		
		assertEquals(expected,calculator.addition(10,10));
		
	}
}
