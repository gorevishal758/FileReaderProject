package com.junit;

import java.util.ArrayList;
import java.util.List;

import org.assertj.core.util.Arrays;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MockMvcBuilder;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.junit.Entity.Book;
import com.junit.controller.BookController;
import com.junit.repository.BookRepo;


@ExtendWith(MockitoExtension.class)
public class BookControllerTest {

	private MockMvc mockMvc;
	
	@InjectMocks
	BookController bookController;
	
	ObjectMapper objectMapper=new ObjectMapper();
	ObjectWriter objectWriter=objectMapper.writer();
	
	@Mock
	private BookRepo bookRepo;
	
	Book RECORD_1=new Book(1L,"Hindi","Learn hindi",3);
	Book RECORD_2=new Book(1L,"English","Learn English",4);
	Book RECORD_3=new Book(1L,"Marathi","Learn Marathi",5);
	
	@BeforeEach
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc=MockMvcBuilders.standaloneSetup(bookController).build();
		
	}
	
	@Test
	public void getAllBookRecordsTest() throws Exception {
		
	List<Book> records=new ArrayList<>(java.util.Arrays.asList(RECORD_1,RECORD_2,RECORD_3));
	
	Mockito.when(bookRepo.findAll()).thenReturn(records);
	
	
	
	}
	
}
