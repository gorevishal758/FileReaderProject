package com.crudpractice;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.crudpractice.controller.UserController;
import com.crudpractice.entity.User;
import com.crudpractice.service.UserService;

@ExtendWith(MockitoExtension.class)
public class UserControllerTest {

	@InjectMocks
	private UserController userController;

	@Mock
	private UserService service;

	@BeforeEach
	public void setUp() {
		System.out.println("Test case for Create user running");
	}

	@Test
	@Disabled
	@DisplayName("Test success scenario of create user")
	void testCreateUser() {

		User user = new User();
		user.setFirstName("dummy name");

		User Svaeduser = new User();
		Svaeduser.setUserId(1);
		Svaeduser.setFirstName("Vishal");
		Svaeduser.setLastName("Gore");
		Svaeduser.setAddress("Pune");
		Mockito.when(service.createUser(user)).thenReturn(Svaeduser);

		ResponseEntity<User> response = userController.createUser(user);

		Assertions.assertNotNull(response.getBody().getUserId());
		Assertions.assertEquals(HttpStatus.CREATED.value(), response.getStatusCodeValue());

	}

	@AfterEach
	void tearDown() {
		System.out.println("End of create");
	}
	// Test case for get user

	@Test
	@Disabled
	@DisplayName("Get all user test case")
	void testGetAllUser() {
		List<User> user = new ArrayList<>();

		User getUser = new User();
		getUser.setUserId(1);
		getUser.setFirstName("ram");
		getUser.setLastName("sen");
		getUser.setAddress("mumbai");
		user.add(getUser);
		Mockito.when(service.getAllUser()).thenReturn(user);
		ResponseEntity<List<User>> response = userController.getAllUser();

		Assertions.assertEquals(1, response.getBody().size());

		Assertions.assertEquals(HttpStatus.OK.value(), response.getStatusCodeValue());

	}

	// put mapping test
	@Test
	@DisplayName("Update user test case")
	void testUpdateUser() {

		User user = new User();

		User update = new User();

		update.setLastName("sharma");
		 Mockito.when(service.updateUser(Mockito.eq("1"), Mockito.any(User.class))).thenReturn(update);
		 ResponseEntity<User> response = userController.updateUser("1", update);

		
		Assertions.assertEquals("sharma", response.getBody().getLastName());
		  Assertions.assertEquals(HttpStatus.ACCEPTED.value(), response.getStatusCodeValue());
	}
}
