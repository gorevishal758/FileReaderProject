package com.crudpractice.service;

import java.util.List;
import java.util.Optional;

import com.crudpractice.entity.User;

public interface UserService {

	//save or create user
	User createUser(User user);
	//get list of user
	List<User> getAllUser();
	// get user by id
Optional<User> getUserById(String userId);
	//update user
	User updateUser(String userId,User user);
	//Delete user
	void deleteUser(String userId);
	
}
