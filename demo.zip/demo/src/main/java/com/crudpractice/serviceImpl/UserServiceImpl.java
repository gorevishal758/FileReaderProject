package com.crudpractice.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crudpractice.entity.User;
import com.crudpractice.repository.UserRepository;
import com.crudpractice.service.UserService;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserRepository userRepository;
	
	@Override
	public User createUser(User user) {
		
		return userRepository.save(user);

	}

	@Override
	public List<User> getAllUser() {
	
		return userRepository.findAll();
	}

	@Override
	public Optional<User> getUserById(String userId) {
		
		return userRepository.findById(userId);
	}

	@Override
	public User updateUser(String userId, User user) {
		
		Optional<User> userIsPresent=userRepository.findById(userId);
		
		User userPresent=null;
		
		if(userIsPresent.isPresent()) {
			
			userPresent=userIsPresent.get();
			
			userPresent.setFirstName(user.getFirstName());
			userPresent.setLastName(user.getLastName());
			userPresent.setAddress(user.getAddress());
		}
		else {
			throw new RuntimeException("Employee id not found :"+userId);
		}
		return userRepository.save(user);
	}

	@Override
	public void deleteUser(String userId) {

		userRepository.deleteById(userId);
		
	}

}
